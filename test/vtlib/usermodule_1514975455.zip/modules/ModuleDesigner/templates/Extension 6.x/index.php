<?php

global $currentModule;

echo 'Congratulations for installing '.$currentModule;

?>
