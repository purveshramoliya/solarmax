1.Download the smackcitrus.zip file and extract it.
2.Upload the smackcitrus theme into vtigercrm/layouts/vlayout/skins/
3.After uploading it, Go to "Administrator" and click "My Preferences" in VtigerCRM.
4.Select the theme as smackcitrus and save it.

Note: You need  to put entry in the file vtigercrm/modules/Vtiger/helpers/Util.php line no.613 like this 'smackcitrus'=> '#008C8C'


