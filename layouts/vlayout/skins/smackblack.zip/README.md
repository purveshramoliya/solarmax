1.Download the smackblack.zip file and extract it.
2.Upload the smackblack theme into vtigercrm/layouts/vlayout/skins/
3.After uploading it, Go to "Administrator" and click "My Preferences" in VtigerCRM.
4.Select the theme as smackblack and save it.

Note: You need  to put entry in the file vtigercrm/modules/Vtiger/helpers/Util.php line no.613 like this 'smackblack'=> '#000000'


